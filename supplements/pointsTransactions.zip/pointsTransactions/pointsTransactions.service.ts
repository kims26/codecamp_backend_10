import { Injectable } from '@nestjs/common';

@Injectable()
export class PointsTransactionsService {
  create(): string {
    return '등록되었습니다.';
  }
}
